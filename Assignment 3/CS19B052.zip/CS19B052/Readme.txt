- Code files in 'Code' Directory
-To run the code:
-python mytcp.py -i <double> -m <double> -n <double> -f <double> -s <double> -T <int> -o outfile
-Output file will be generated in same directory

- Graphs :
-python graphs.py
-Generate Plots in Plots folder

- Report
-CS19B052.pdf